package com.expense.reimbursement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpenseReimbursementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExpenseReimbursementApplication.class, args);
    }
}